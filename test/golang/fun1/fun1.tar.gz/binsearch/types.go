package binsearch

type DummyElem struct{
	index int	
	msg string
} 