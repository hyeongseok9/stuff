package fun1

func hello()string{
	return "world"
}